// One command for every test: npm test
const { spawnSync } = require('child_process');
const path = require('path');
let bad = 0;
for (const [name, file] of [['core logic', 'core.test.js'], ['companion logic', 'companion.test.js'], ['static checks', 'static.test.js'], ['gnome extension (mocked)', 'gnome-mock.test.mjs'], ['app window', 'app.test.js']]) {
  console.log('\n== ' + name + ' ==');
  if (spawnSync(process.execPath, [path.join(__dirname, file)], { stdio: 'inherit' }).status !== 0) bad++;
}
console.log('\n' + (bad ? bad + ' suite(s) FAILED' : 'All suites passed'));
process.exit(bad ? 1 : 0);
