# Format Bridge (pill + tray companion)

Copy from Slack, Jira, Confluence, Outlook, Google Docs, a spreadsheet, an AI chat or a terminal, and paste it correctly anywhere: Slack, Jira, Confluence, email, Google Docs, markdown (GitHub, Claude, ChatGPT, Cursor) or plain text.

## What it fixes
- **Tables**: Slack text tables, spreadsheet ranges, psql/mysql output and HTML tables become real tables in Jira, Confluence, Slack, email and Docs.
- **Destination-aware copy**: each destination gets the format it actually understands. Pairs that already paste fine (Slack to Slack, Jira to Confluence) are passed through untouched, and the app says so.
- **Lists and indentation**: •/◦/▪ bullets, a) b) numbering, mixed tabs and spaces, and Outlook's fake list paragraphs become real nested lists.
- **Email**: an email-safe output (inline styles only, bordered tables, code that keeps its indentation) for Gmail, Outlook and Apple Mail.
- **Clipboard inspector**: every format on the clipboard (text, HTML, RTF, images, app-private formats), with a one-click report for bug hunting.

## Run it (Linux, then Mac)
Needs Node.js 18 or newer.
```
npm install
npm start
```
Format Bridge is a **tray companion with a pill**.

### The pill
A slim black pill tucked into the right edge of the screen, shown only in the apps you choose (by default Slack, Jira, Confluence and Google Docs). Its dot turns orange when you've copied something. **Click it** to open the options: **Fix for Jira** (matching the app in front) or any other destination. Then paste with Ctrl+V: the pill never takes focus, so the paste lands in the app you were in. It tucks itself away after a fix, with › or Esc, or after a few idle seconds. **Open full view** shows the preview and inspector. Drag the ⋮⋮ grip to move it up or down.

Choose the apps in **tray menu → Pill → Choose apps…**: tick the ones you want, pick what each one means (Notion → Markdown, say), or add your own by window title or app id. You can also have it in every app.

**On Ubuntu with Wayland** (the default), apps can't see which window is in front or float a small window over other apps, so a tiny GNOME helper does both: it tells Format Bridge which app is in front and draws the pill as part of the desktop. It shares only the focused window's app id and title, on your computer. Install it (and again after updates):
```
sh gnome-extension/install.sh
```
then log out and back in (GNOME on Wayland only loads extensions at login). Without it there's no pill on Wayland; the tray menu still works. X11 and macOS need nothing extra (on a Mac, allow Format Bridge to control System Events and your browser when asked).

### The tray
Also there: no window or taskbar entry, just an icon in the top bar (the menu bar on a Mac). It turns on *Start at login* the first time it runs.
- **Tray menu → Convert clipboard for → Jira** (or Slack, Confluence, Email, Docs, Markdown, Text): converts what you copied and puts it back on the clipboard. Paste. No window needed.
- **Ctrl+Alt+V** (⌘⌥V on Mac) or **Open Format Bridge** shows a small popover with the preview and the clipboard inspector. Esc or clicking away hides it. Under Wayland the global shortcut may not register; the tray menu always works.
- On Linux it notices new copies, so the popover already shows your latest one. On a Mac it reads only when you open it or use the tray menu, because macOS asks permission whenever an app reads the clipboard on its own.
- Copies that a password manager marks as secret are ignored, and nothing you copy is written to disk.
- Ubuntu shows tray icons through its AppIndicator extension, which is on by default. If you don't see the icon, run `gnome-extensions enable ubuntu-appindicators@ubuntu.com`.

## Build an installable app
```
npm run dist:linux   # dist/*.AppImage and dist/*.deb
npm run dist:mac     # dist/*.dmg (run this on a Mac)
```
The Mac build is unsigned. The first time, right-click the app and choose Open. Signing and notarizing for other people needs an Apple Developer account.

## Tests
`npm test` runs the core logic tests, static checks (wiring, security settings, packaging) and the app window tests in Chromium. A git pre-commit hook runs them:
```
git config core.hooksPath .githooks
```

## Shortcuts, sizes and PDF

- **Shortcuts** (Settings › Shortcuts, in the pill, the tray menu or the full view; each can be turned off or re-recorded):
  Ctrl Alt V pastes what you copied, fixed for the app you're in · Ctrl Shift Alt V pastes it as plain text ·
  Ctrl Alt F opens or closes the pill. Off by default: Ctrl Alt H (paste the copy before), Ctrl Alt A (auto-format on/off),
  Ctrl Alt B (full view), Ctrl Alt P (save as PDF). On GNOME the helper catches them, so they work in every app.
- **Size**: Small, Medium or Large (Settings › Size). **Look**: six themes (Settings › Look). Both change without logging out.
- **From a PDF**: text copied from a PDF viewer (or a PDF in the browser) is put back together: lines joined into
  paragraphs, split words rejoined, bullets turned into lists, ligatures and page numbers fixed.
- **To a PDF**: "PDF ↓" in the pill, or Save as PDF in the full view, saves what you copied as a clean PDF in Downloads.

## Mac

The Mac version is the same app: the pill, looks, sizes, history, shortcuts, PDF and settings are shared code.
The pill is a small floating panel that never takes focus from the app you're in.

Run it from this folder on a Mac (Node 20 or newer):

```
npm install
npm start
```

or build an app to keep: `npm run dist:mac` (makes a .dmg in `dist/`). It isn't signed, so the first time,
right-click the app → Open.

Permissions macOS will ask for, and what each one is for:

- **Automation → System Events** (asked on first run): to see which app is in front, so the pill shows only in your chosen apps.
- **Automation → Chrome / Safari** (asked the first time you use one): the tab title, to tell Slack, Jira and Confluence apart in a browser.
- **Accessibility** (optional, only if you want it): lets the pill press ⌘V for you ("Paste for me" in Settings) and read the
  Slack desktop app's window title for the channel name. Without it, the pill copies and you press ⌘V.

## Closing the pill

✕ (top corner of the open pill) hides it everywhere. Bring it back with Ctrl Alt F (or the shortcut you set),
or "Show the pill" in the tray / menu bar menu.
