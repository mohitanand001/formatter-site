#!/bin/bash
# Format Bridge — start script
cd "$(dirname "$0")"

# Install GNOME extension if not already installed
EXT_DIR="$HOME/.local/share/gnome-shell/extensions/format-bridge-focus@formatbridge.dev"
if [ ! -d "$EXT_DIR" ] || [ "gnome-extension/format-bridge-focus@formatbridge.dev/extension.js" -nt "$EXT_DIR/extension.js" ]; then
  echo "Installing/updating GNOME extension..."
  bash gnome-extension/install.sh 2>/dev/null
fi

# Install node modules if missing
if [ ! -d "node_modules" ]; then
  echo "Installing dependencies..."
  npm install --omit=dev 2>/dev/null
fi

# Kill any existing instance
pkill -f "electron.*format-bridge" 2>/dev/null
sleep 0.3

echo "Starting Format Bridge..."
npx electron . &
disown
echo "Format Bridge is running in the tray."
