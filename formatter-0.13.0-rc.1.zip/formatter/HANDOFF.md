# Format Bridge: handoff

Electron tray app + GNOME Shell extension (the "pill") that converts copied content between Slack, Jira, Confluence, Docs, Email, etc.
App folder: `/home/mohit/Desktop/all-desktop/claude/format-bridge-app`. CLI: `formatter-linker --install | --start | --stop | --restart | --status`.
Tests: `node test/run-all.js` (all pass). Owner prefers to do the GUI testing; do basic tests only. Don't commit unless asked. Git author Mohit Anand.

## Architecture
- `main.js`: `shellSpec()` builds ONE JSON spec drawn by both pills: window pill (`src/pill.js`, `pill.css`) and GNOME extension (`gnome-extension/format-bridge-focus@formatbridge.dev/extension.js`, `stylesheet.css`, St widgets).
- Actions are strings `verb:arg` matching `/^[a-z]+:[a-z0-9]*$/` (pill.js, preload-pill.js, extension.js, main.js, lib/focus.js, pinned by static tests). Encode data in the arg (`dswap:1t3`, `tn:12v3800`).
- GNOME gotchas: no CSS opacity (set actor.opacity), no flex-wrap, fields vs methods name clash, extension reload needs logout/login on Wayland.

## Done recently (all deployed)
Pill shrunk (floors 380/350/446), auto-collapse after click (timer no longer cancelled by later specs), clicked chip blue not green, clipboard history gated behind `FEATURES.clipboardHistory` (env `FB_HISTORY=1`), saved People list (Settings → People: name→email so @mentions paste as mailto links; applied in `outputs()`/`savePdf` in src/app.js), Edit apps page (swap/hide/add), squircle chips, constant panel height.

## Design tuner (just built, NOT yet seen working)
`FB_TUNE=1 formatter-linker --start` shows a panel of sliders under the pill. `lib/tune.js` = knob list + CSS generator (only changed knobs emit rules; S/L scale from M); actions `tn:`/`tc:`/`tr:`/`tcopy:`; `main.js` `addTune()/onTune()`; window UI `src/tuner.js`; GNOME UI `_applyTune/_buildTuner/_tuneKnob/_setTuneCss` in extension.js (live stylesheet in ~/.cache). "Copy all" puts JSON of changed values on the clipboard, to be hardcoded as defaults, then the tuner removed.
**Open bug:** on the owner's GNOME desktop the pill appeared ~2x too tall with nothing drawn in the tuner area. Cause unknown. Diagnose with: `journalctl --user -b | grep -i format-bridge`, `gnome-extensions info format-bridge-focus@formatbridge.dev`. Suspects: exception in `_buildTuner` (Slider import/ScrollView), root height = panel + TUNER_H (400) with tuner not painting, or extension not reloaded. `_applyTune` is wrapped in try/catch and logs "format-bridge tuner:".

## Next
1. Fix the tuner bug above and let the owner tune; then bake the copied JSON in as defaults.
2. Linked pairs (designed, not built): after pasting into a specific Jira/Confluence/Doc/Slack channel, remember the pair; the chip splits into [jump back | clipboard-recopy]. Slack channel link `slack://channel?team=T…&id=C…` needs IDs: read from Slack's local data (unverified), else learn from a copied Slack link, else just focus Slack. Per pair, no expiry, "Unlink" in Settings.
3. Mac verification/packaging, custom apps ("Other…").
