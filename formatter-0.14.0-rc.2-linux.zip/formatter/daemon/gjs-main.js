#!/usr/bin/env -S gjs -m
// Formatter's background program for GNOME. It replaces the old Electron app: GJS is part of GNOME
// itself, so nothing else is downloaded. This file only connects the logic in core.js to the desktop:
// the GNOME helper (pill, clipboard, shortcuts) over D-Bus, files, notifications and the PDF drawer.
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';

const here = Gio.File.new_for_uri(import.meta.url).get_parent();     // .../daemon
const root = here.get_parent();                                       // the app folder
const DEBUG = !!GLib.getenv('FB_DEBUG');
const log = (...a) => { if (DEBUG) print('[formatter] ' + a.join(' ')); };

// ---------------------------------------------------------------- loading the shared code
const readText = (path) => new TextDecoder().decode(GLib.file_get_contents(path)[1]);
const cache = {};
function makeRequire(dir) {
  return function require(rel) {
    let p = rel.startsWith('.') ? GLib.build_filenamev([dir, rel]) : rel;
    // Tidy "a/../b" and "./x".
    const parts = [];
    p.split('/').forEach((s) => { if (s === '..') parts.pop(); else if (s && s !== '.') parts.push(s); });
    p = '/' + parts.join('/');
    if (!/\.js$/.test(p)) p += '.js';
    if (cache[p]) return cache[p].exports;
    const module = { exports: {} };
    cache[p] = module;
    new Function('module', 'exports', 'require', readText(p))(module, module.exports, makeRequire(GLib.path_get_dirname(p)));
    return module.exports;
  };
}
// The converter: plain scripts that fill in window.FB. The same files the tests run.
// GJS already defines window (read-only); only add it if some version doesn't.
if (typeof globalThis.window === 'undefined') Object.defineProperty(globalThis, 'window', { value: globalThis, configurable: true });
const CORE = ['ast-utils', 'lift', 'lists', 'people', 'terminal', 'pdf', 'detect', 'minidom', 'normalize-html', 'normalize-markdown', 'normalize-mrkdwn', 'render-slack', 'render-slack-html', 'render-jira', 'render-github', 'render-gdocs', 'render-email', 'render-text', 'fidelity', 'engine'];
CORE.forEach((f) => new Function(readText(root.get_child('src').get_child('core').get_child(f + '.js').get_path()))());
const req = makeRequire(here.get_path());
const { createCore } = req('./core.js');
const { pdfItems } = req('./pdf-doc.js');

// ---------------------------------------------------------------- the GNOME helper over D-Bus
const bus = Gio.DBus.session;
const DEST = 'org.gnome.Shell';
const OBJ = '/dev/formatbridge/Focus';
const IFACE = 'dev.formatbridge.Focus';
const enc = (s) => GLib.base64_encode(new TextEncoder().encode(s));
const dec = (s) => new TextDecoder().decode(GLib.base64_decode(s));
function call(method, args, timeout = 3000) {
  return new Promise((resolve) => {
    try {
      bus.call(DEST, OBJ, IFACE, method, args, null, Gio.DBusCallFlags.NONE, timeout, null, (c, res) => {
        try { resolve(c.call_finish(res)); } catch (e) { resolve(null); }
      });
    } catch (e) { resolve(null); }
  });
}
const text = (reply) => { try { return reply ? reply.deepUnpack()[0] : null; } catch (e) { return null; } };
const json = (reply) => { const t = text(reply); if (t === null) return null; try { return JSON.parse(dec(t)); } catch (e) { return null; } };

const shell = {
  setPill: (spec) => { call('SetPill', new GLib.Variant('(s)', [enc(JSON.stringify(spec))])); },
  async readClip() {
    const j = json(await call('ReadClipboard', null));
    if (!j) return null;
    return { formats: Array.isArray(j.mimetypes) ? j.mimetypes.map(String) : [], secret: !!j.secret, text: typeof j.text === 'string' ? j.text : '', html: typeof j.html === 'string' ? j.html : '' };
  },
  async writeClip(mime, data) {
    if (!/^text\/(plain|html)$/.test(mime)) return false;
    return (await call('WriteClipboard', new GLib.Variant('(ss)', [mime, enc(String(data))]))) !== null;
  },
  paste: (shift) => { call('Paste', new GLib.Variant('(b)', [!!shift])); },
  async setShortcuts(list) {
    const j = json(await call('SetShortcuts', new GLib.Variant('(s)', [enc(JSON.stringify(list))])));
    return Array.isArray(j) ? j.map(String) : null;
  },
};

// ---------------------------------------------------------------- files, notifications, PDF
const configDir = GLib.build_filenamev([GLib.get_user_config_dir(), 'formatter']);
const settingsPath = GLib.build_filenamev([configDir, 'settings.json']);
const pkg = (() => { try { return JSON.parse(readText(root.get_child('package.json').get_path())); } catch (e) { return {}; } })();

function notify(title, body) {
  try {
    bus.call('org.freedesktop.Notifications', '/org/freedesktop/Notifications', 'org.freedesktop.Notifications', 'Notify',
      new GLib.Variant('(susssasa{sv}i)', ['Formatter', 0, '', title, body || '', [], {}, 4000]), null, Gio.DBusCallFlags.NONE, 2000, null, null);
  } catch (e) { log('notification failed:', e.message); }
}
function openUri(uri) { try { Gio.AppInfo.launch_default_for_uri(uri, null); } catch (e) { log('open failed:', e.message); } }
function showInFolder(path) {
  const uri = GLib.filename_to_uri(path, null);
  try {
    bus.call('org.freedesktop.FileManager1', '/org/freedesktop/FileManager1', 'org.freedesktop.FileManager1', 'ShowItems',
      new GLib.Variant('(ass)', [[uri], 'formatter']), null, Gio.DBusCallFlags.NONE, 2000, null, (c, res) => {
        try { c.call_finish(res); } catch (e) { openUri(GLib.filename_to_uri(GLib.path_get_dirname(path), null)); }
      });
  } catch (e) { openUri(GLib.filename_to_uri(GLib.path_get_dirname(path), null)); }
}
async function savePdf(doc) {
  try {
    const items = pdfItems(doc.ast);
    const { renderPdf } = await import('./pdf.js');
    const dir = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD) || GLib.build_filenamev([GLib.get_home_dir(), 'Downloads']);
    GLib.mkdir_with_parents(dir, 0o755);
    const base = String(doc.title || 'Formatter').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60) || 'Formatter';
    let name = base + '.pdf';
    for (let i = 2; GLib.file_test(GLib.build_filenamev([dir, name]), GLib.FileTest.EXISTS) && i < 100; i++) name = base + ' (' + i + ').pdf';
    const path = GLib.build_filenamev([dir, name]);
    renderPdf(items, path);
    log('saved PDF:', path);
    return { ok: true, name, path };
  } catch (e) {
    log('PDF failed:', e && e.message);
    return { ok: false };
  }
}

// ---------------------------------------------------------------- timers
const timers = new Set();
function setTimeoutG(fn, ms) {
  const t = { id: 0 };
  t.id = GLib.timeout_add(GLib.PRIORITY_DEFAULT, Math.max(1, ms), () => { timers.delete(t); try { fn(); } catch (e) { log('timer error:', e.message); } return GLib.SOURCE_REMOVE; });
  timers.add(t);
  return t;
}
function clearTimeoutG(t) { if (t && timers.has(t)) { timers.delete(t); GLib.source_remove(t.id); } }

// ---------------------------------------------------------------- go
const core = createCore({
  version: pkg.version || '0.0.0',
  home: GLib.get_home_dir(),
  log,
  store: {
    read: () => { try { return readText(settingsPath); } catch (e) { return null; } },
    write: (s) => { GLib.mkdir_with_parents(configDir, 0o700); GLib.file_set_contents(settingsPath, s); },
  },
  shell, notify, savePdf,
  openPath: (p) => openUri(GLib.filename_to_uri(p, null)),
  showInFolder,
  now: () => Date.now(),
  setTimeout: setTimeoutG,
  clearTimeout: clearTimeoutG,
});

const safe = (what, fn) => (...a) => { try { const r = fn(...a); if (r && r.catch) r.catch((e) => log(what + ' failed:', e && e.message)); } catch (e) { log(what + ' failed:', e && e.message); } };

// Which window is in front: the helper tells us when it changes, and we ask now and then as a backup.
let lastKey = '';
let failures = 0;
let unavailable = false;
function windowInfo(j) {
  if (!j) return null;
  const pill = Number(j.pill) || 0;
  return { win: { app: String(j.app || ''), title: String(j.title || '') }, pill };
}
function onWindow(info) {
  const key = info.win.app + '\n' + info.win.title + '\n' + info.pill;
  if (key === lastKey && !unavailable) return;
  lastKey = key;
  failures = 0;
  unavailable = false;
  log('front window:', JSON.stringify(info.win), 'helper v' + info.pill);
  core.focus(info.win, info.pill);
}
async function probe() {
  const info = windowInfo(json(await call('Get', null, 1500)));
  if (info) { onWindow(info); return; }
  failures++;
  if (failures >= 3 && !unavailable) { unavailable = true; lastKey = ''; core.focus(null); }
}

bus.signal_subscribe(DEST, IFACE, null, OBJ, null, Gio.DBusSignalFlags.NONE, safe('signal', (_c, _s, _p, _i, name, params) => {
  const arg = params.deepUnpack()[0];
  if (name === 'Action') core.action(arg);
  else if (name === 'ClipboardChanged') core.clipboardChanged();
  else if (name === 'Changed') { let j = null; try { j = JSON.parse(dec(arg)); } catch (e) { j = null; } const info = windowInfo(j); if (info) onWindow(info); }
}));

const loop = new GLib.MainLoop(null, false);
let ownedName = false;
let duplicate = false;
Gio.bus_own_name(Gio.BusType.SESSION, 'dev.formatbridge.Daemon', Gio.BusNameOwnerFlags.DO_NOT_QUEUE,
  null,
  () => { ownedName = true; },
  () => { if (!ownedName) { duplicate = true; print('Formatter is already running.'); loop.quit(); } });
try { GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, 15, () => { loop.quit(); return GLib.SOURCE_REMOVE; }); } catch (e) { /* not fatal */ }
try { GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, 2, () => { loop.quit(); return GLib.SOURCE_REMOVE; }); } catch (e) { /* not fatal */ }

GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
  safe('start', async () => {
    if (!ownedName) await new Promise((r) => setTimeoutG(r, 300)); // give the name a moment
    if (duplicate) return;
    await probe();
    await core.start();
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1800, () => { probe().catch(() => {}); return GLib.SOURCE_CONTINUE; });
  })();
  return GLib.SOURCE_REMOVE;
});
loop.run();
