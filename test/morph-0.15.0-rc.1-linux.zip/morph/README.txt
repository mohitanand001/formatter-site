Morph 0.15.0-rc.1 for Linux (GNOME)

1. Open a terminal in this folder and run:   bin/morph --install
2. If it asks, log out and back in once. Morph then starts by itself.

Other commands: --start  --stop  --restart  --status  --uninstall
Needs: GNOME (Ubuntu, Fedora Workstation...) with gjs, which is already part of GNOME.
Nothing you copy leaves your computer.
